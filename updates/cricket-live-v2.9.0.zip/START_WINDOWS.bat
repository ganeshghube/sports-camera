@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo Virtual environment not found.
  echo Run: bash tools/setup_gitbash.sh
  pause
  exit /b 1
)
".venv\Scripts\python.exe" run.py
